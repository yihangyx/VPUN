# JumperVPN 注册器

纯API注册版本，可部署到Vercel/Railway/Render等平台。

## 功能

- ✅ 一键注册账号
- ✅ 自动获取免费时长
- ✅ 返回邮箱、密码、Token
- ✅ 支持iOS/Windows模式

## 本地运行

```bash
pip install -r requirements.txt
python app.py
```

访问 http://127.0.0.1:5000

## 部署到 Vercel

1. Fork 或上传代码到 GitHub
2. 访问 https://vercel.com/new
3. 导入你的仓库
4. 点击 Deploy

## 部署到 Railway

1. 访问 https://railway.app/new
2. 选择 "Deploy from repo"
3. 导入你的仓库
4. 点击 Deploy

## 部署到 Render

1. 访问 https://render.com
2. 点击 "New +" → "Web Service"
3. 导入你的仓库
4. 配置：
   - Runtime: Python 3
   - Build Command: `pip install -r requirements.txt`
   - Start Command: `gunicorn app:app`
5. 点击 Deploy

## 文件说明

- `app.py` - 主程序文件
- `requirements.txt` - Python依赖
- `vercel.json` - Vercel配置
- `Procfile` - Railway/Heroku配置
