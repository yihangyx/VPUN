#!/usr/bin/env python3
"""JumperVPN 自动续期 v7 — Web版"""
import json, sys, os, time, hashlib, hmac, uuid, base64, re, sqlite3, random, string, subprocess, threading, shutil
import urllib.request, urllib.error, ssl
from datetime import datetime
from pathlib import Path
from flask import Flask, render_template_string, request, jsonify

BASE = 'https://api.jumperservice.com/v1/'
SIGN_KEY = '000000000000000000018d91e471e0989cda27df505a453f2b7635294f2ddf23e3b122acc99c9e9f1e14'
MAIL_TM = 'https://api.mail.tm'
APP_DIR = Path(os.environ.get('APPDATA', '')) / 'com.jumper' / 'Jumper'
SP_PATH = APP_DIR / 'shared_preferences.json'
CONFIGS_DIR = APP_DIR / 'configs'
DB_PATH = APP_DIR / 'jumper_desktop_db.sqlite'
JUMPER_EXE = r'C:\Program Files\Jumper\Jumper.exe'
INVITE_CODE = '9QGE5V'
PC_NAME = os.environ.get('COMPUTERNAME', 'DESKTOP')

ctx = ssl.create_default_context()
no_proxy_handler = urllib.request.ProxyHandler({})
opener = urllib.request.build_opener(no_proxy_handler, urllib.request.HTTPSHandler(context=ctx))
opener.addheaders = []

app = Flask(__name__)

session_data = {
    'running': False,
    'logs': [],
    'status': '就绪',
    'current_token': '',
    'current_imei': '',
    'current_email': '',
    'current_pwd_raw': '',
    'current_pwd_md5': ''
}

HTML_TEMPLATE = '''
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>奕涵ju - JumperVPN</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'Segoe UI', Arial, sans-serif; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; padding: 20px; }
        .container { max-width: 900px; margin: 0 auto; background: white; border-radius: 12px; box-shadow: 0 10px 40px rgba(0,0,0,0.2); overflow: hidden; }
        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 24px; text-align: center; }
        .header h1 { font-size: 28px; margin-bottom: 8px; }
        .content { padding: 20px; }
        .btn-group { display: flex; flex-wrap: wrap; gap: 10px; margin-bottom: 20px; }
        .btn { padding: 12px 20px; border: none; border-radius: 8px; cursor: pointer; font-size: 14px; font-weight: 600; transition: all 0.3s; }
        .btn:disabled { opacity: 0.5; cursor: not-allowed; }
        .btn-primary { background: #667eea; color: white; }
        .btn-primary:hover:not(:disabled) { background: #5a6fd6; }
        .btn-success { background: #10b981; color: white; }
        .btn-success:hover:not(:disabled) { background: #0da272; }
        .btn-warning { background: #f59e0b; color: white; }
        .btn-warning:hover:not(:disabled) { background: #d9820a; }
        .btn-info { background: #3b82f6; color: white; }
        .btn-info:hover:not(:disabled) { background: #2563eb; }
        .btn-danger { background: #ef4444; color: white; }
        .btn-danger:hover:not(:disabled) { background: #dc2626; }
        .btn-secondary { background: #6b7280; color: white; }
        .btn-secondary:hover:not(:disabled) { background: #4b5563; }
        .config-section { background: #f3f4f6; padding: 16px; border-radius: 8px; margin-bottom: 20px; }
        .config-section h3 { margin-bottom: 12px; color: #374151; }
        .config-row { display: flex; flex-wrap: wrap; gap: 12px; align-items: center; margin-bottom: 10px; }
        .config-item { display: flex; align-items: center; gap: 8px; }
        label { font-weight: 600; color: #374151; font-size: 14px; }
        input[type="text"], input[type="password"] { padding: 8px 12px; border: 2px solid #e5e7eb; border-radius: 6px; font-size: 14px; transition: border-color 0.3s; }
        input[type="text"]:focus, input[type="password"]:focus { outline: none; border-color: #667eea; }
        .radio-group { display: flex; gap: 16px; }
        .radio-item { display: flex; align-items: center; gap: 6px; }
        .checkbox-item { display: flex; align-items: center; gap: 6px; }
        .status-bar { background: #1f2937; color: white; padding: 10px 20px; font-family: 'Consolas', monospace; }
        .log-box { background: #1f2937; color: #10b981; padding: 16px; border-radius: 8px; font-family: 'Consolas', monospace; font-size: 13px; height: 350px; overflow-y: auto; line-height: 1.6; }
        .log-entry { margin-bottom: 4px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>奕涵ju</h1>
            <p>JumperVPN 自动续期</p>
        </div>
        <div class="content">
            <div class="btn-group">
                <button class="btn btn-primary" onclick="doAction('full_flow')" id="btn_register">🚀 一键注册+登录 (24h)</button>
                <button class="btn btn-success" onclick="doAction('quick')" id="btn_quick">⚡ 快速续期 (1h)</button>
                <button class="btn btn-info" onclick="doAction('check')" id="btn_check">🔍 查看状态</button>
                <button class="btn btn-warning" onclick="doAction('login')" id="btn_login">🔑 API登录</button>
                <button class="btn btn-danger" onclick="doAction('kill')" id="btn_kill">☠ 杀Jumper</button>
                <button class="btn btn-secondary" onclick="clearLogs()" style="margin-left: auto;">🧹 清日志</button>
            </div>
            
            <div class="config-section">
                <h3>配置</h3>
                <div class="config-row">
                    <div class="config-item">
                        <label>邀请码:</label>
                        <input type="text" id="invite" value="9QGE5V" style="width: 100px;">
                    </div>
                    <div class="config-item">
                        <label>密码:</label>
                        <input type="text" id="pwd" value="Xiangzi6681" style="width: 150px;">
                    </div>
                    <div class="config-item">
                        <label>邮箱(登录用):</label>
                        <input type="text" id="email" style="width: 250px;">
                    </div>
                </div>
                <div class="config-row">
                    <div class="config-item">
                        <label>节点Key:</label>
                        <input type="text" id="node_key" value="a0a7d970-28b4-4b58-a8ac-b9b0fa44ee98" style="width: 320px;">
                    </div>
                    <div class="radio-group">
                        <div class="radio-item">
                            <input type="radio" name="mode" id="mode_ios" value="ios" checked>
                            <label for="mode_ios">iOS模式</label>
                        </div>
                        <div class="radio-item">
                            <input type="radio" name="mode" id="mode_windows" value="windows">
                            <label for="mode_windows">Windows模式</label>
                        </div>
                    </div>
                    <div class="checkbox-item" style="margin-left: 20px;">
                        <input type="checkbox" id="autostart" checked>
                        <label for="autostart">完成后启动Jumper</label>
                    </div>
                </div>
            </div>
            
            <div class="log-box" id="log_box"></div>
        </div>
        <div class="status-bar" id="status_bar">就绪</div>
    </div>

    <script>
        let pollInterval;

        function doAction(action) {
            const config = {
                invite: document.getElementById('invite').value,
                pwd: document.getElementById('pwd').value,
                email: document.getElementById('email').value,
                node_key: document.getElementById('node_key').value,
                mode: document.querySelector('input[name="mode"]:checked').value,
                autostart: document.getElementById('autostart').checked
            };
            
            fetch('/api/' + action, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(config)
            }).then(r => r.json()).then(data => {
                if (data.success) {
                    startPolling();
                }
            });
        }

        function startPolling() {
            setButtons(false);
            if (pollInterval) clearInterval(pollInterval);
            pollInterval = setInterval(pollStatus, 500);
        }

        function pollStatus() {
            fetch('/api/status').then(r => r.json()).then(data => {
                updateLogs(data.logs);
                document.getElementById('status_bar').textContent = data.status;
                document.getElementById('email').value = data.current_email || '';
                if (!data.running) {
                    clearInterval(pollInterval);
                    setButtons(true);
                }
            });
        }

        function updateLogs(logs) {
            const logBox = document.getElementById('log_box');
            logBox.innerHTML = logs.map(log => '<div class="log-entry">' + log + '</div>').join('');
            logBox.scrollTop = logBox.scrollHeight;
        }

        function clearLogs() {
            fetch('/api/clear_logs', { method: 'POST' }).then(r => r.json()).then(data => {
                updateLogs([]);
            });
        }

        function setButtons(enabled) {
            const buttons = ['btn_register', 'btn_quick', 'btn_check', 'btn_login', 'btn_kill'];
            buttons.forEach(id => {
                document.getElementById(id).disabled = !enabled;
            });
        }

        pollStatus();
    </script>
</body>
</html>
'''

class JumperWeb:
    def __init__(self):
        self.session = session_data

    def log(self, msg):
        ts = datetime.now().strftime('%H:%M:%S')
        line = f'[{ts}] {msg}'
        self.session['logs'].append(line)

    def clear_log(self):
        self.session['logs'] = []

    def set_status(self, msg):
        self.session['status'] = msg

    def md5(self, text):
        return hashlib.md5(text.encode('utf-8')).hexdigest()

    def make_sign(self, path):
        return hmac.new(SIGN_KEY.encode(), path.encode(), hashlib.sha256).hexdigest()

    def api_call(self, path, method='GET', body=None, token=None, imei=None, mode='ios'):
        url = BASE + path.lstrip('/')
        sign = self.make_sign('/v1/' + path.lstrip('/'))
        data = json.dumps(body).encode('utf-8') if body else None
        req = urllib.request.Request(url, data=data, method=method)

        req.add_header('app-id', '2')
        req.add_header('version', '1.0.8')
        req.add_header('buildNumber', '3')
        req.add_header('x-sign', sign)
        req.add_header('Accept', '*/*')

        if mode == 'ios':
            req.add_header('os', 'ios')
            req.add_header('Content-Language', 'en-us')
            req.add_header('User-Agent',
                'JumperVPN/1.0.8 (com.jumper.net.solutions.vpn; build:3; iOS 18.6.0) Alamofire/5.10.2')
            req.add_header('Accept-Language', 'zh-Hans-CN;q=1.0')
            req.add_header('Accept-Encoding', 'br;q=1.0, gzip;q=0.9, deflate;q=0.8')
        else:
            req.add_header('os', 'windows')
            req.add_header('Content-Language', 'zh-cn')
            req.add_header('User-Agent', 'JumperVPN/1.0.8')

        if imei:
            req.add_header('imei', imei.strip('{}'))
            req.add_header('device-name', PC_NAME)
        if token:
            req.add_header('j-token', token)
        if data:
            req.add_header('Content-Type', 'application/json')

        try:
            resp = opener.open(req, timeout=15)
            raw = resp.read()
            try: raw = __import__('gzip').decompress(raw)
            except: pass
            return json.loads(raw.decode('utf-8'))
        except urllib.error.HTTPError as e:
            raw = e.read()
            try: raw = __import__('gzip').decompress(raw)
            except: pass
            try: return json.loads(raw.decode('utf-8'))
            except: return {'code': e.code, 'msg': raw.decode('utf-8','replace')[:200]}
        except Exception as e:
            return {'code': -1, 'msg': str(e)[:200]}

    def http_get(self, url, headers=None):
        req = urllib.request.Request(url)
        if headers:
            for k, v in headers.items(): req.add_header(k, v)
        resp = opener.open(req, timeout=10)
        return json.loads(resp.read().decode('utf-8'))

    def http_post(self, url, body, headers=None):
        data = json.dumps(body).encode('utf-8')
        req = urllib.request.Request(url, data=data, method='POST')
        req.add_header('Content-Type', 'application/json')
        if headers:
            for k, v in headers.items(): req.add_header(k, v)
        resp = opener.open(req, timeout=10)
        return json.loads(resp.read().decode('utf-8'))

    def decode_jwt_payload(self, token):
        try:
            parts = token.split('.')
            payload = parts[1]
            payload += '=' * (4 - len(payload) % 4)
            return json.loads(base64.urlsafe_b64decode(payload))
        except:
            return None

    def ensure_device_token(self, imei=None, mode='ios'):
        if not imei:
            imei = '{' + str(uuid.uuid4()).upper() + '}'
            self.session['current_imei'] = imei
        self.log(f'  device/init ...')
        result = self.api_call('device/init', imei=imei, mode=mode)
        if result.get('code') != 200:
            self.log(f'  ❌ device/init 失败: {result}')
            return None, imei
        device_token = result['data']['user_info']['token']
        self.log(f'  ✅ device token OK')
        return device_token, imei

    def _kill_jumper(self):
        self.log('杀掉 JumperVPN ...')
        for proc in ['Jumper.exe', 'JumperCli.exe', 'JumperVPN.exe']:
            subprocess.run(['taskkill', '/F', '/IM', proc], capture_output=True, timeout=5)
        time.sleep(1)
        self.log('✅ JumperVPN 已停止')

    def _clean_data(self):
        self.log('清理本地数据 ...')
        if SP_PATH.exists(): SP_PATH.unlink()
        if CONFIGS_DIR.exists(): shutil.rmtree(str(CONFIGS_DIR), ignore_errors=True)
        if DB_PATH.exists():
            for _ in range(5):
                try: DB_PATH.unlink(); break
                except PermissionError:
                    subprocess.run(['taskkill', '/F', '/IM', 'Jumper.exe'], capture_output=True, timeout=5)
                    time.sleep(1)
        self.log('✅ 本地数据已清理')

    def _create_temp_email(self):
        self.log('创建临时邮箱 ...')
        try:
            domains = self.http_get(f'{MAIL_TM}/domains')
            if isinstance(domains, list):
                domain = domains[0].get('domain', 'deltajohnsons.com')
            else:
                domain = domains.get('hydra:member', [{}])[0].get('domain', 'deltajohnsons.com')

            username = ''.join(random.choices(string.ascii_lowercase + string.digits, k=10))
            email = f'{username}@{domain}'
            mail_pwd = ''.join(random.choices(string.ascii_letters + string.digits, k=16))

            self.http_post(f'{MAIL_TM}/accounts', {'address': email, 'password': mail_pwd})
            self.log(f'邮箱: {email}')
        except urllib.error.HTTPError as e:
            err = e.read().decode('utf-8','replace')[:200]
            self.log(f'❌ 创建邮箱失败: {err}')
            return None, None, None

        try:
            token_result = self.http_post(f'{MAIL_TM}/token', {'address': email, 'password': mail_pwd})
            mail_token = token_result.get('token', '')
            if not mail_token:
                self.log('❌ mail token 获取失败')
                return None, None, None
        except urllib.error.HTTPError as e:
            self.log(f'❌ mail token 失败: {e.read().decode("utf-8","replace")[:200]}')
            return None, None, None

        return email, mail_pwd, mail_token

    def _wait_for_code(self, mail_token, max_wait=90):
        self.log(f'等待验证码 (最多{max_wait}秒)...')
        start = time.time()
        while time.time() - start < max_wait:
            try:
                messages = self.http_get(f'{MAIL_TM}/messages',
                    headers={'Authorization': f'Bearer {mail_token}'})
                msg_list = messages.get('hydra:member', []) if isinstance(messages, dict) else messages
                for msg in msg_list:
                    msg_id = msg.get('id', '')
                    if not msg_id: continue
                    detail = self.http_get(f'{MAIL_TM}/messages/{msg_id}',
                        headers={'Authorization': f'Bearer {mail_token}'})
                    body_text = detail.get('text', '') or detail.get('html', '') or ''
                    match = re.search(r'(?:验证码|code|Code|CODE)[：:\s]*(\d{4,6})', body_text)
                    if not match:
                        match = re.search(r'\b(\d{4,6})\b', body_text)
                    if match:
                        code = match.group(1)
                        self.log(f'✅ 验证码: {code}')
                        return code
            except: pass
            time.sleep(3)
        self.log('❌ 等待验证码超时')
        return None

    def _write_config(self, token, imei, user_info, default_node, node_url=''):
        self.log('写入本地配置 ...')
        APP_DIR.mkdir(parents=True, exist_ok=True)

        try:
            with open(SP_PATH, 'r', encoding='utf-8') as f:
                sp = json.load(f)
        except:
            sp = {}

        user_data = {
            'uid': user_info.get('uid', ''),
            'email': user_info.get('email', '') or self.session['current_email'],
            'invite_code': user_info.get('invite_code', ''),
            'free_end_time': user_info.get('free_end_time', ''),
            'free_end_time_str': user_info.get('free_end_time_str', ''),
            'free_end_time_str_en_us': user_info.get('free_end_time_str_en_us', ''),
            'free_end_time_str_zh_cn': user_info.get('free_end_time_str_zh_cn', ''),
            'vip_end_time': user_info.get('vip_end_time', ''),
            'title': user_info.get('title', PC_NAME),
            'imei': imei,
            'token': token,
            'allow_connect': user_info.get('allow_connect', 1),
            'is_vip': user_info.get('is_vip', 0),
        }
        sp['flutter.user'] = json.dumps(user_data, ensure_ascii=False)
        sp['flutter.isLoggedIn'] = True

        if default_node:
            dn = dict(default_node)
            if node_url:
                dn['node_url'] = node_url
            dn['checked'] = True
            sp['flutter.defaultNode'] = json.dumps(dn, ensure_ascii=False)

        sp['flutter.hasShownOnboarding'] = True
        sp['flutter.hasAcceptedTerms'] = True

        with open(SP_PATH, 'w', encoding='utf-8') as f:
            json.dump(sp, f, ensure_ascii=False, indent=2)

        CONFIGS_DIR.mkdir(parents=True, exist_ok=True)
        for old in CONFIGS_DIR.glob('*.json'):
            old.unlink()

        profile_id = str(uuid.uuid4())
        config_path = CONFIGS_DIR / f'{profile_id}.json'
        singbox_outbound = {
            "type": "vless",
            "tag": "Japan-g01-vless-reality",
            "server": "jpga01.jumperservice.com",
            "server_port": 19001,
            "uuid": "0709ba80-f353-4636-85ce-43b82990ac2d",
            "flow": "xtls-rprx-vision",
            "tls": {
                "enabled": True,
                "server_name": "www.speedtest.org",
                "utls": {"enabled": True, "fingerprint": "chrome"},
                "reality": {
                    "enabled": True,
                    "public_key": "g1f1wLjim5gOVGnI5LGUV0dL4iFXPoiepOPZfSxJe14"
                }
            }
        }
        with open(config_path, 'w', encoding='utf-8') as f:
            json.dump({"outbounds": [singbox_outbound]}, f, ensure_ascii=False, indent=2)

        try:
            conn = sqlite3.connect(str(DB_PATH))
            cur = conn.cursor()
            cur.execute('DELETE FROM profile_entries')
            cur.execute('''INSERT INTO profile_entries
                (id, type, active, name, url, last_update, update_interval)
                VALUES (?, ?, ?, ?, ?, ?, ?)''',
                (profile_id, 'local', 1,
                 default_node.get('title', 'Japan-g01') if default_node else 'Japan-g01',
                 None, datetime.now().isoformat(), None))
            conn.commit()
            conn.close()
        except Exception as e:
            self.log(f'  ⚠ SQLite: {e}')

        self.log('✅ 配置已写入')

    def _full_flow(self, config):
        try:
            self._kill_jumper()
            self._clean_data()
            time.sleep(0.5)

            self.log('[1/7] device/init ...')
            imei = '{' + str(uuid.uuid4()).upper() + '}'
            self.session['current_imei'] = imei
            device_token, imei = self.ensure_device_token(imei, mode=config['mode'])
            if not device_token: return

            self.log('[2/7] 创建临时邮箱 ...')
            email, mail_pwd, mail_token = self._create_temp_email()
            if not email: return

            self.log(f'[3/7] 发送验证码 → {email} ...')
            result = self.api_call('user/send_email_code', method='POST',
                                  body={'email': email, 'type': 10},
                                  token=device_token, imei=imei, mode=config['mode'])
            if result.get('code') not in (200, 0):
                self.log(f'❌ 发送失败: {result}')
                return
            self.log('✅ 验证码已发送')

            self.log('[4/7] 等待验证码 ...')
            code = self._wait_for_code(mail_token)
            if not code: return

            pwd_raw = config['pwd']
            pwd_md5 = self.md5(pwd_raw)
            invite = config['invite']
            self.log(f'[5/7] 注册 ({email}) ...')

            reg_pwd = None
            for pwd_attempt, label in [(pwd_md5, 'MD5'), (pwd_raw, '明文')]:
                result = self.api_call('user/signup', method='POST',
                                      body={'email': email, 'password': pwd_attempt,
                                            'repassword': pwd_attempt, 'code': code,
                                            'invite_code': invite},
                                      token=device_token, imei=imei, mode=config['mode'])
                if result.get('code') in (200, 0):
                    reg_pwd = pwd_attempt
                    self.log(f'  ✅ 注册成功 (密码格式: {label})')
                    break
                self.log(f'  {label}失败: {result.get("message","")}')
            if not reg_pwd:
                self.log('❌ 两种密码格式都注册失败')
                return

            data = result.get('data', {})
            reg_user = data.get('user_info', {})
            free = reg_user.get('free_remaining_time', 0)
            end = reg_user.get('free_end_time', '')
            h, m = free // 3600, (free % 3600) // 60
            self.log(f'✅ 注册成功! {h}小时{m}分 | 到期: {end}')

            self.session['current_email'] = email
            self.session['current_pwd_raw'] = pwd_raw
            self.session['current_pwd_md5'] = reg_pwd

            self.log('[6/7] API 登录 ...')
            login_ok = False
            for pwd_attempt, label in [(pwd_md5, 'MD5'), (pwd_raw, '明文')]:
                login_result = self.api_call('user/signin', method='POST',
                                            body={'email': email, 'password': pwd_attempt},
                                            token=device_token, imei=imei, mode=config['mode'])
                if login_result.get('code') in (200, 0):
                    login_token = login_result.get('data', {}).get('user_info', {}).get('token', '')
                    if login_token:
                        self.session['current_token'] = login_token
                        login_ok = True
                        self.log(f'  ✅ 登录成功 (密码格式: {label})')
                        break
                self.log(f'  {label}登录失败: {login_result.get("message","")}')
            if not login_ok:
                self.session['current_token'] = reg_user.get('token', device_token)
                self.log('  ⚠ 登录失败，用注册 token')

            self.log('[7/7] 连接节点 & 写配置 & 启动 ...')
            full_info = self.api_call('user/info', token=self.session['current_token'], imei=imei, mode=config['mode'])
            user_info = full_info.get('data', reg_user) if full_info.get('code') in (200, 0) else reg_user

            node_result = self.api_call('node/group', token=self.session['current_token'], imei=imei, mode=config['mode'])
            rows = []
            if node_result.get('code') in (200, 0):
                rows = node_result.get('data', {}).get('rows', [])
                if rows:
                    self.log(f'✅ {len(rows)} 个节点')

            node_url = ''
            node_key = config['node_key'] or (rows[0].get('key','') if rows else '')
            if node_key:
                conn = self.api_call('node/connect', method='POST',
                                    body={'key': node_key},
                                    token=self.session['current_token'], imei=imei, mode=config['mode'])
                if conn.get('code') in (200, 0):
                    node_url = conn.get('data', {}).get('node_url', '')
                    self.log('✅ 节点连接成功')

            self._write_config(self.session['current_token'], imei, user_info,
                              data.get('default_node_info', {}), node_url)

            if config['autostart']:
                self.log('启动 JumperVPN ...')
                subprocess.Popen([JUMPER_EXE])
                self.log('✅ JumperVPN 已启动')

            self.set_status(f'✅ 到期: {end} ({h}h{m}m)')
        except Exception as e:
            self.log(f'❌ 异常: {e}')
            import traceback; self.log(traceback.format_exc()[:500])
            self.set_status(f'错误: {e}')
        finally:
            self.session['running'] = False

    def _login(self, config):
        try:
            email = config['email'].strip()
            pwd_raw = config['pwd'].strip()
            if not email or not pwd_raw:
                self.log('❌ 请填写邮箱和密码')
                return

            imei = self.session['current_imei'] or '{' + str(uuid.uuid4()).upper() + '}'
            self.session['current_imei'] = imei
            self.log(f'API 登录 {email} ...')

            device_token, imei = self.ensure_device_token(imei, mode=config['mode'])
            if not device_token: return

            pwd_md5 = self.md5(pwd_raw)
            for pwd_attempt, label in [(pwd_md5, 'MD5'), (pwd_raw, '明文')]:
                result = self.api_call('user/signin', method='POST',
                                      body={'email': email, 'password': pwd_attempt},
                                      token=device_token, imei=imei, mode=config['mode'])
                if result.get('code') in (200, 0):
                    user_info = result.get('data', {}).get('user_info', {})
                    token = user_info.get('token', '')
                    if token:
                        self.session['current_token'] = token
                        self.session['current_email'] = email
                        self.session['current_pwd_raw'] = pwd_raw
                        self.session['current_pwd_md5'] = pwd_attempt
                        free = user_info.get('free_remaining_time', 0)
                        end = user_info.get('free_end_time', '')
                        h, m = free // 3600, (free % 3600) // 60
                        self.log(f'✅ 登录成功 ({label})! 剩余 {h}h{m}m | 到期: {end}')

                        full_info = self.api_call('user/info', token=token, imei=imei, mode=config['mode'])
                        full_user = full_info.get('data', user_info) if full_info.get('code') in (200, 0) else user_info

                        node_result = self.api_call('node/group', token=token, imei=imei, mode=config['mode'])
                        rows = []
                        if node_result.get('code') in (200, 0):
                            rows = node_result.get('data', {}).get('rows', [])

                        node_url = ''
                        node_key = config['node_key'] or (rows[0].get('key','') if rows else '')
                        if node_key:
                            conn = self.api_call('node/connect', method='POST',
                                                body={'key': node_key}, token=token, imei=imei, mode=config['mode'])
                            if conn.get('code') in (200, 0):
                                node_url = conn.get('data', {}).get('node_url', '')

                        self._write_config(token, imei, full_user, {}, node_url)

                        if config['autostart']:
                            self.log('启动 JumperVPN ...')
                            subprocess.Popen([JUMPER_EXE])
                            self.log('✅ JumperVPN 已启动')

                        self.set_status(f'✅ 已登录 | 剩余 {h}h{m}m | 到期 {end}')
                        return
                else:
                    self.log(f'  {label} 登录: {result.get("message","")}')
            self.log('❌ 两种密码格式都登录失败')
        except Exception as e:
            self.log(f'❌ 异常: {e}')
            self.set_status(f'错误: {e}')
        finally:
            self.session['running'] = False

    def _quick(self, config):
        try:
            self._kill_jumper()
            self._clean_data()
            time.sleep(0.5)

            imei = '{' + str(uuid.uuid4()).upper() + '}'
            self.session['current_imei'] = imei
            self.log(f'IMEI: {imei}')
            self.log('device/init ...')
            result = self.api_call('device/init', imei=imei, mode=config['mode'])
            if result.get('code') != 200:
                self.log(f'❌ 失败: {result}')
                return
            user_info = result['data']['user_info']
            token = user_info['token']
            self.session['current_token'] = token
            free = user_info.get('free_remaining_time', 0)
            end = user_info.get('free_end_time', '')
            h, m = free // 3600, (free % 3600) // 60
            self.log(f'✅ 1小时免费! 到期: {end}')

            node_result = self.api_call('node/group', token=token, imei=imei, mode=config['mode'])
            rows = []
            if node_result.get('code') in (200, 0):
                rows = node_result.get('data', {}).get('rows', [])

            node_url = ''
            node_key = config['node_key'] or (rows[0].get('key','') if rows else '')
            if node_key:
                conn = self.api_call('node/connect', method='POST',
                                    body={'key': node_key}, token=token, imei=imei, mode=config['mode'])
                if conn.get('code') in (200, 0):
                    node_url = conn.get('data', {}).get('node_url', '')

            self._write_config(token, imei, user_info,
                              result['data'].get('default_node_info', {}), node_url)

            if config['autostart']:
                self.log('启动 JumperVPN ...')
                subprocess.Popen([JUMPER_EXE])
                self.log('✅ JumperVPN 已启动')

            self.set_status(f'✅ 到期: {end}')
        except Exception as e:
            self.log(f'❌ 异常: {e}')
            self.set_status(f'错误: {e}')
        finally:
            self.session['running'] = False

    def _check(self, config):
        try:
            if not SP_PATH.exists():
                self.log('❌ 配置文件不存在')
                if self.session['current_token']:
                    result = self.api_call('user/info', token=self.session['current_token'], imei=self.session['current_imei'], mode=config['mode'])
                    self.log(f'API: {json.dumps(result, ensure_ascii=False)[:300]}')
                self.set_status('未登录')
                return

            with open(SP_PATH, 'r', encoding='utf-8') as f:
                sp = json.load(f)
            user = json.loads(sp.get('flutter.user', '{}'))
            token = user.get('token', '') or self.session['current_token']
            imei = user.get('imei', '') or self.session['current_imei']
            email = user.get('email', '')

            if not token:
                self.log('❌ 无 token')
                self.set_status('未登录')
                return

            result = self.api_call('user/info', token=token, imei=imei, mode=config['mode'])
            if result.get('code') in (200, 0):
                info = result.get('data', {})
                free = info.get('free_remaining_time', 0)
                end = info.get('free_end_time', '')
                h, m = free // 3600, (free % 3600) // 60
                self.log(f'Email: {email}')
                self.log(f'IMEI: {imei}')
                self.log(f'剩余: {h}小时{m}分 ({free}秒)')
                self.log(f'到期: {end}')
                self.log(f'VIP: {"是" if info.get("is_vip") else "否"} | 允许连接: {"是" if info.get("allow_connect") else "否"}')
                self.set_status(f'剩余 {h}h{m}m | 到期 {end}')
            else:
                self.log(f'查询失败: {result}')
                self.set_status('查询失败')
        except Exception as e:
            self.log(f'❌ 异常: {e}')
            self.set_status(f'错误: {e}')
        finally:
            self.session['running'] = False

    def _kill(self, config):
        self._kill_jumper()
        self.set_status('JumperVPN 已停止')

jumper = JumperWeb()

@app.route('/')
def index():
    return render_template_string(HTML_TEMPLATE)

@app.route('/api/status')
def get_status():
    return jsonify({
        'running': session_data['running'],
        'logs': session_data['logs'],
        'status': session_data['status'],
        'current_email': session_data['current_email']
    })

@app.route('/api/clear_logs', methods=['POST'])
def clear_logs():
    jumper.clear_log()
    return jsonify({'success': True})

@app.route('/api/full_flow', methods=['POST'])
def full_flow():
    if session_data['running']:
        return jsonify({'success': False, 'error': '正在运行中'})
    session_data['running'] = True
    jumper.set_status('一键注册+登录...')
    config = request.json
    threading.Thread(target=jumper._full_flow, args=(config,), daemon=True).start()
    return jsonify({'success': True})

@app.route('/api/login', methods=['POST'])
def login():
    if session_data['running']:
        return jsonify({'success': False, 'error': '正在运行中'})
    session_data['running'] = True
    jumper.set_status('API 登录...')
    config = request.json
    threading.Thread(target=jumper._login, args=(config,), daemon=True).start()
    return jsonify({'success': True})

@app.route('/api/quick', methods=['POST'])
def quick():
    if session_data['running']:
        return jsonify({'success': False, 'error': '正在运行中'})
    session_data['running'] = True
    jumper.set_status('快速续期...')
    config = request.json
    threading.Thread(target=jumper._quick, args=(config,), daemon=True).start()
    return jsonify({'success': True})

@app.route('/api/check', methods=['POST'])
def check():
    if session_data['running']:
        return jsonify({'success': False, 'error': '正在运行中'})
    session_data['running'] = True
    jumper.set_status('查询中...')
    config = request.json
    threading.Thread(target=jumper._check, args=(config,), daemon=True).start()
    return jsonify({'success': True})

@app.route('/api/kill', methods=['POST'])
def kill():
    config = request.json if request.is_json else {}
    jumper._kill(config)
    return jsonify({'success': True})

if __name__ == '__main__':
    print('JumperVPN Web版启动中...')
    print('请在浏览器中访问: http://127.0.0.1:5000')
    app.run(host='127.0.0.1', port=5000, debug=False)
