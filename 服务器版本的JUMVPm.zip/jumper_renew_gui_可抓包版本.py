#!/usr/bin/env python3
"""JumperVPN 自动续期 v7 — 修复版"""
import json, sys, os, time, hashlib, hmac, uuid, base64, re, sqlite3, random, string, subprocess, threading, shutil
import urllib.request, urllib.error, ssl
from datetime import datetime
from pathlib import Path
import tkinter as tk
from tkinter import ttk, scrolledtext

BASE = 'https://api.jumperservice.com/v1/'
SIGN_KEY = '000000000000000000018d91e471e0989cda27df505a453f2b7635294f2ddf23e3b122acc99c9e9f1e14'
MAIL_TM = 'https://api.mail.tm'
APP_DIR = Path(os.environ.get('APPDATA', '')) / 'com.jumper' / 'Jumper'
SP_PATH = APP_DIR / 'shared_preferences.json'
CONFIGS_DIR = APP_DIR / 'configs'
DB_PATH = APP_DIR / 'jumper_desktop_db.sqlite'
JUMPER_EXE = r'C:\Program Files\Jumper\Jumper.exe'
INVITE_CODE = '9QGE5V'
PC_NAME = os.environ.get('COMPUTERNAME', 'DESKTOP')

import ssl, urllib.request

ctx = ssl.create_default_context()
no_proxy_handler = urllib.request.ProxyHandler({})
opener = urllib.request.build_opener(no_proxy_handler, urllib.request.HTTPSHandler(context=ctx))
opener.addheaders = []

def resource_path(relative_path):
    """PyInstaller 打包后资源路径"""
    if hasattr(sys, '_MEIPASS'):
        return os.path.join(sys._MEIPASS, relative_path)
    return os.path.join(os.path.abspath(os.path.dirname(__file__)), relative_path)

class JumperApp:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title('奕涵ju')
        self.root.geometry('800x640')
        self.root.resizable(True, True)
        icon_path = resource_path('favicon.ico')
        if os.path.exists(icon_path):
            self.root.iconbitmap(icon_path)
        self.running = False
        self.current_token = ''
        self.current_imei = ''
        self.current_email = ''
        self.current_pwd_raw = ''
        self.current_pwd_md5 = ''

        # 顶部按钮
        btn_frame = ttk.Frame(self.root, padding=8)
        btn_frame.pack(fill=tk.X)

        self.btn_register = ttk.Button(btn_frame, text='🚀 一键注册+登录 (24h)', command=self.do_full_flow)
        self.btn_register.pack(side=tk.LEFT, padx=4)

        self.btn_quick = ttk.Button(btn_frame, text='⚡ 快速续期 (1h)', command=self.do_quick)
        self.btn_quick.pack(side=tk.LEFT, padx=4)

        self.btn_check = ttk.Button(btn_frame, text='🔍 查看状态', command=self.do_check)
        self.btn_check.pack(side=tk.LEFT, padx=4)

        self.btn_login = ttk.Button(btn_frame, text='🔑 API登录', command=self.do_login)
        self.btn_login.pack(side=tk.LEFT, padx=4)

        self.btn_kill = ttk.Button(btn_frame, text='☠ 杀Jumper', command=self.do_kill)
        self.btn_kill.pack(side=tk.LEFT, padx=4)

        self.btn_clear = ttk.Button(btn_frame, text='🧹 清日志', command=self.clear_log)
        self.btn_clear.pack(side=tk.RIGHT, padx=4)

        # 状态栏
        self.status_var = tk.StringVar(value='就绪')
        ttk.Label(self.root, textvariable=self.status_var, relief=tk.SUNKEN, anchor=tk.W).pack(fill=tk.X, side=tk.BOTTOM)

        # 日志
        self.log_box = scrolledtext.ScrolledText(self.root, wrap=tk.WORD, font=('Consolas', 10))
        self.log_box.pack(fill=tk.BOTH, expand=True, padx=4, pady=4)
        self.log_box.config(state=tk.DISABLED)

        # 配置区
        cfg_frame = ttk.LabelFrame(self.root, text='配置', padding=4)
        cfg_frame.pack(fill=tk.X, padx=4, pady=(0,4))

        row1 = ttk.Frame(cfg_frame); row1.pack(fill=tk.X, pady=2)
        ttk.Label(row1, text='邀请码:').pack(side=tk.LEFT)
        self.invite_var = tk.StringVar(value=INVITE_CODE)
        ttk.Entry(row1, textvariable=self.invite_var, width=10).pack(side=tk.LEFT, padx=(0,12))
        ttk.Label(row1, text='密码:').pack(side=tk.LEFT)
        self.pwd_var = tk.StringVar(value='Xiangzi6681')
        ttk.Entry(row1, textvariable=self.pwd_var, width=16).pack(side=tk.LEFT, padx=(0,12))
        ttk.Label(row1, text='邮箱(登录用):').pack(side=tk.LEFT)
        self.email_var = tk.StringVar(value='')
        ttk.Entry(row1, textvariable=self.email_var, width=28).pack(side=tk.LEFT)

        row2 = ttk.Frame(cfg_frame); row2.pack(fill=tk.X, pady=2)
        ttk.Label(row2, text='节点Key:').pack(side=tk.LEFT)
        self.node_var = tk.StringVar(value='a0a7d970-28b4-4b58-a8ac-b9b0fa44ee98')
        ttk.Entry(row2, textvariable=self.node_var, width=32).pack(side=tk.LEFT, padx=(0,12))
        self.mode_var = tk.StringVar(value='ios')
        ttk.Radiobutton(row2, text='iOS模式', variable=self.mode_var, value='ios').pack(side=tk.LEFT)
        ttk.Radiobutton(row2, text='Windows模式', variable=self.mode_var, value='windows').pack(side=tk.LEFT)
        self.autostart_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(row2, text='完成后启动Jumper', variable=self.autostart_var).pack(side=tk.LEFT, padx=(12,0))

    def log(self, msg):
        ts = datetime.now().strftime('%H:%M:%S')
        line = f'[{ts}] {msg}\n'
        self.log_box.config(state=tk.NORMAL)
        self.log_box.insert(tk.END, line)
        self.log_box.see(tk.END)
        self.log_box.config(state=tk.DISABLED)
        self.root.update_idletasks()

    def clear_log(self):
        self.log_box.config(state=tk.NORMAL)
        self.log_box.delete('1.0', tk.END)
        self.log_box.config(state=tk.DISABLED)

    def set_status(self, msg):
        self.status_var.set(msg)
        self.root.update_idletasks()

    def set_buttons(self, enabled):
        state = tk.NORMAL if enabled else tk.DISABLED
        for btn in [self.btn_register, self.btn_quick, self.btn_check, self.btn_login, self.btn_kill]:
            btn.config(state=state)

    # ============================================================
    # API
    # ============================================================
    def md5(self, text):
        return hashlib.md5(text.encode('utf-8')).hexdigest()

    def make_sign(self, path):
        return hmac.new(SIGN_KEY.encode(), path.encode(), hashlib.sha256).hexdigest()

    def api_call(self, path, method='GET', body=None, token=None, imei=None):
        url = BASE + path.lstrip('/')
        sign = self.make_sign('/v1/' + path.lstrip('/'))
        data = json.dumps(body).encode('utf-8') if body else None
        req = urllib.request.Request(url, data=data, method=method)

        mode = self.mode_var.get()
        req.add_header('app-id', '2')
        req.add_header('version', '1.0.8')
        req.add_header('buildNumber', '3')
        req.add_header('x-sign', sign)
        req.add_header('Accept', '*/*')

        if mode == 'ios':
            req.add_header('os', 'ios')
            req.add_header('Content-Language', 'en-us')
            req.add_header('User-Agent',
                'JumperVPN/1.0.8 (com.jumper.net.solutions.vpn; build:3; iOS 18.6.0) Alamofire/5.10.2')
            req.add_header('Accept-Language', 'zh-Hans-CN;q=1.0')
            req.add_header('Accept-Encoding', 'br;q=1.0, gzip;q=0.9, deflate;q=0.8')
        else:
            req.add_header('os', 'windows')
            req.add_header('Content-Language', 'zh-cn')
            req.add_header('User-Agent', 'JumperVPN/1.0.8')

        if imei:
            req.add_header('imei', imei.strip('{}'))
            req.add_header('device-name', PC_NAME)
        if token:
            req.add_header('j-token', token)
        if data:
            req.add_header('Content-Type', 'application/json')

        try:
            resp = opener.open(req, timeout=15)
            raw = resp.read()
            try: raw = __import__('gzip').decompress(raw)
            except: pass
            return json.loads(raw.decode('utf-8'))
        except urllib.error.HTTPError as e:
            raw = e.read()
            try: raw = __import__('gzip').decompress(raw)
            except: pass
            try: return json.loads(raw.decode('utf-8'))
            except: return {'code': e.code, 'msg': raw.decode('utf-8','replace')[:200]}
        except Exception as e:
            return {'code': -1, 'msg': str(e)[:200]}

    def http_get(self, url, headers=None):
        req = urllib.request.Request(url)
        if headers:
            for k, v in headers.items(): req.add_header(k, v)
        resp = opener.open(req, timeout=10)
        return json.loads(resp.read().decode('utf-8'))

    def http_post(self, url, body, headers=None):
        data = json.dumps(body).encode('utf-8')
        req = urllib.request.Request(url, data=data, method='POST')
        req.add_header('Content-Type', 'application/json')
        if headers:
            for k, v in headers.items(): req.add_header(k, v)
        resp = opener.open(req, timeout=10)
        return json.loads(resp.read().decode('utf-8'))

    def decode_jwt_payload(self, token):
        try:
            parts = token.split('.')
            payload = parts[1]
            payload += '=' * (4 - len(payload) % 4)
            return json.loads(base64.urlsafe_b64decode(payload))
        except:
            return None

    def ensure_device_token(self, imei=None):
        if not imei:
            imei = '{' + str(uuid.uuid4()).upper() + '}'
            self.current_imei = imei
        self.log(f'  device/init ...')
        result = self.api_call('device/init', imei=imei)
        if result.get('code') != 200:
            self.log(f'  ❌ device/init 失败: {result}')
            return None, imei
        device_token = result['data']['user_info']['token']
        self.log(f'  ✅ device token OK')
        return device_token, imei

    # ============================================================
    # 一键注册+登录
    # ============================================================
    def do_full_flow(self):
        if self.running: return
        self.running = True
        self.set_buttons(False)
        self.set_status('一键注册+登录...')
        threading.Thread(target=self._full_flow, daemon=True).start()

    def _full_flow(self):
        try:
            self._kill_jumper()
            self._clean_data()
            time.sleep(0.5)

            # 1. device/init
            self.log('[1/7] device/init ...')
            imei = '{' + str(uuid.uuid4()).upper() + '}'
            self.current_imei = imei
            device_token, imei = self.ensure_device_token(imei)
            if not device_token: return

            # 2. 临时邮箱
            self.log('[2/7] 创建临时邮箱 ...')
            email, mail_pwd, mail_token = self._create_temp_email()
            if not email: return

            # 3. 发验证码
            self.log(f'[3/7] 发送验证码 → {email} ...')
            result = self.api_call('user/send_email_code', method='POST',
                                  body={'email': email, 'type': 10},
                                  token=device_token, imei=imei)
            if result.get('code') not in (200, 0):
                self.log(f'❌ 发送失败: {result}')
                return
            self.log('✅ 验证码已发送')

            # 4. 等验证码
            self.log('[4/7] 等待验证码 ...')
            code = self._wait_for_code(mail_token)
            if not code: return

            # 5. 注册
            pwd_raw = self.pwd_var.get()
            pwd_md5 = self.md5(pwd_raw)
            invite = self.invite_var.get()
            self.log(f'[5/7] 注册 ({email}) ...')

            reg_pwd = None
            for pwd_attempt, label in [(pwd_md5, 'MD5'), (pwd_raw, '明文')]:
                result = self.api_call('user/signup', method='POST',
                                      body={'email': email, 'password': pwd_attempt,
                                            'repassword': pwd_attempt, 'code': code,
                                            'invite_code': invite},
                                      token=device_token, imei=imei)
                if result.get('code') in (200, 0):
                    reg_pwd = pwd_attempt
                    self.log(f'  ✅ 注册成功 (密码格式: {label})')
                    break
                self.log(f'  {label}失败: {result.get("message","")}')
            if not reg_pwd:
                self.log('❌ 两种密码格式都注册失败')
                return

            data = result.get('data', {})
            reg_user = data.get('user_info', {})
            free = reg_user.get('free_remaining_time', 0)
            end = reg_user.get('free_end_time', '')
            h, m = free // 3600, (free % 3600) // 60
            self.log(f'✅ 注册成功! {h}小时{m}分 | 到期: {end}')

            self.current_email = email
            self.current_pwd_raw = pwd_raw
            self.current_pwd_md5 = reg_pwd
            self.email_var.set(email)

            # 6. API 登录拿正式 user token
            self.log('[6/7] API 登录 ...')
            login_ok = False
            for pwd_attempt, label in [(pwd_md5, 'MD5'), (pwd_raw, '明文')]:
                login_result = self.api_call('user/signin', method='POST',
                                            body={'email': email, 'password': pwd_attempt},
                                            token=device_token, imei=imei)
                if login_result.get('code') in (200, 0):
                    login_token = login_result.get('data', {}).get('user_info', {}).get('token', '')
                    if login_token:
                        self.current_token = login_token
                        login_ok = True
                        self.log(f'  ✅ 登录成功 (密码格式: {label})')
                        break
                self.log(f'  {label}登录失败: {login_result.get("message","")}')
            if not login_ok:
                self.current_token = reg_user.get('token', device_token)
                self.log('  ⚠ 登录失败，用注册 token')

            # 7. 连接节点 + 写配置 + 启动
            self.log('[7/7] 连接节点 & 写配置 & 启动 ...')
            full_info = self.api_call('user/info', token=self.current_token, imei=imei)
            user_info = full_info.get('data', reg_user) if full_info.get('code') in (200, 0) else reg_user

            node_result = self.api_call('node/group', token=self.current_token, imei=imei)
            rows = []
            if node_result.get('code') in (200, 0):
                rows = node_result.get('data', {}).get('rows', [])
                if rows:
                    self.log(f'✅ {len(rows)} 个节点')

            node_url = ''
            node_key = self.node_var.get() or (rows[0].get('key','') if rows else '')
            if node_key:
                conn = self.api_call('node/connect', method='POST',
                                    body={'key': node_key},
                                    token=self.current_token, imei=imei)
                if conn.get('code') in (200, 0):
                    node_url = conn.get('data', {}).get('node_url', '')
                    self.log('✅ 节点连接成功')

            self._write_config(self.current_token, imei, user_info,
                              data.get('default_node_info', {}), node_url)

            if self.autostart_var.get():
                self.log('启动 JumperVPN ...')
                subprocess.Popen([JUMPER_EXE])
                self.log('✅ JumperVPN 已启动')

            self.set_status(f'✅ 到期: {end} ({h}h{m}m)')
        except Exception as e:
            self.log(f'❌ 异常: {e}')
            import traceback; self.log(traceback.format_exc()[:500])
            self.set_status(f'错误: {e}')
        finally:
            self.running = False
            self.set_buttons(True)

    # ============================================================
    # API 登录
    # ============================================================
    def do_login(self):
        if self.running: return
        self.running = True
        self.set_buttons(False)
        self.set_status('API 登录...')
        threading.Thread(target=self._login, daemon=True).start()

    def _login(self):
        try:
            email = self.email_var.get().strip()
            pwd_raw = self.pwd_var.get().strip()
            if not email or not pwd_raw:
                self.log('❌ 请填写邮箱和密码')
                return

            imei = self.current_imei or '{' + str(uuid.uuid4()).upper() + '}'
            self.current_imei = imei
            self.log(f'API 登录 {email} ...')

            # v7: 先 device/init
            device_token, imei = self.ensure_device_token(imei)
            if not device_token: return

            pwd_md5 = self.md5(pwd_raw)
            for pwd_attempt, label in [(pwd_md5, 'MD5'), (pwd_raw, '明文')]:
                result = self.api_call('user/signin', method='POST',
                                      body={'email': email, 'password': pwd_attempt},
                                      token=device_token, imei=imei)
                if result.get('code') in (200, 0):
                    user_info = result.get('data', {}).get('user_info', {})
                    token = user_info.get('token', '')
                    if token:
                        self.current_token = token
                        self.current_email = email
                        self.current_pwd_raw = pwd_raw
                        self.current_pwd_md5 = pwd_attempt
                        free = user_info.get('free_remaining_time', 0)
                        end = user_info.get('free_end_time', '')
                        h, m = free // 3600, (free % 3600) // 60
                        self.log(f'✅ 登录成功 ({label})! 剩余 {h}h{m}m | 到期: {end}')

                        # 连接+写配置+启动
                        full_info = self.api_call('user/info', token=token, imei=imei)
                        full_user = full_info.get('data', user_info) if full_info.get('code') in (200, 0) else user_info

                        node_result = self.api_call('node/group', token=token, imei=imei)
                        rows = []
                        if node_result.get('code') in (200, 0):
                            rows = node_result.get('data', {}).get('rows', [])

                        node_url = ''
                        node_key = self.node_var.get() or (rows[0].get('key','') if rows else '')
                        if node_key:
                            conn = self.api_call('node/connect', method='POST',
                                                body={'key': node_key}, token=token, imei=imei)
                            if conn.get('code') in (200, 0):
                                node_url = conn.get('data', {}).get('node_url', '')

                        self._write_config(token, imei, full_user, {}, node_url)

                        if self.autostart_var.get():
                            self.log('启动 JumperVPN ...')
                            subprocess.Popen([JUMPER_EXE])
                            self.log('✅ JumperVPN 已启动')

                        self.set_status(f'✅ 已登录 | 剩余 {h}h{m}m | 到期 {end}')
                        return
                else:
                    self.log(f'  {label} 登录: {result.get("message","")}')
            self.log('❌ 两种密码格式都登录失败')
        except Exception as e:
            self.log(f'❌ 异常: {e}')
            self.set_status(f'错误: {e}')
        finally:
            self.running = False
            self.set_buttons(True)

    # ============================================================
    # 快速续期
    # ============================================================
    def do_quick(self):
        if self.running: return
        self.running = True
        self.set_buttons(False)
        self.set_status('快速续期...')
        threading.Thread(target=self._quick, daemon=True).start()

    def _quick(self):
        try:
            self._kill_jumper()
            self._clean_data()
            time.sleep(0.5)

            imei = '{' + str(uuid.uuid4()).upper() + '}'
            self.current_imei = imei
            self.log(f'IMEI: {imei}')
            self.log('device/init ...')
            result = self.api_call('device/init', imei=imei)
            if result.get('code') != 200:
                self.log(f'❌ 失败: {result}')
                return
            user_info = result['data']['user_info']
            token = user_info['token']
            self.current_token = token
            free = user_info.get('free_remaining_time', 0)
            end = user_info.get('free_end_time', '')
            h, m = free // 3600, (free % 3600) // 60
            self.log(f'✅ 1小时免费! 到期: {end}')

            node_result = self.api_call('node/group', token=token, imei=imei)
            rows = []
            if node_result.get('code') in (200, 0):
                rows = node_result.get('data', {}).get('rows', [])

            node_url = ''
            node_key = self.node_var.get() or (rows[0].get('key','') if rows else '')
            if node_key:
                conn = self.api_call('node/connect', method='POST',
                                    body={'key': node_key}, token=token, imei=imei)
                if conn.get('code') in (200, 0):
                    node_url = conn.get('data', {}).get('node_url', '')

            self._write_config(token, imei, user_info,
                              result['data'].get('default_node_info', {}), node_url)

            if self.autostart_var.get():
                self.log('启动 JumperVPN ...')
                subprocess.Popen([JUMPER_EXE])
                self.log('✅ JumperVPN 已启动')

            self.set_status(f'✅ 到期: {end}')
        except Exception as e:
            self.log(f'❌ 异常: {e}')
            self.set_status(f'错误: {e}')
        finally:
            self.running = False
            self.set_buttons(True)

    # ============================================================
    # 查看状态
    # ============================================================
    def do_check(self):
        if self.running: return
        self.running = True
        self.set_buttons(False)
        self.set_status('查询中...')
        threading.Thread(target=self._check, daemon=True).start()

    def _check(self):
        try:
            if not SP_PATH.exists():
                self.log('❌ 配置文件不存在')
                if self.current_token:
                    result = self.api_call('user/info', token=self.current_token, imei=self.current_imei)
                    self.log(f'API: {json.dumps(result, ensure_ascii=False)[:300]}')
                self.set_status('未登录')
                return

            with open(SP_PATH, 'r', encoding='utf-8') as f:
                sp = json.load(f)
            user = json.loads(sp.get('flutter.user', '{}'))
            token = user.get('token', '') or self.current_token
            imei = user.get('imei', '') or self.current_imei
            email = user.get('email', '')

            if not token:
                self.log('❌ 无 token')
                self.set_status('未登录')
                return

            result = self.api_call('user/info', token=token, imei=imei)
            if result.get('code') in (200, 0):
                info = result.get('data', {})
                free = info.get('free_remaining_time', 0)
                end = info.get('free_end_time', '')
                h, m = free // 3600, (free % 3600) // 60
                self.log(f'Email: {email}')
                self.log(f'IMEI: {imei}')
                self.log(f'剩余: {h}小时{m}分 ({free}秒)')
                self.log(f'到期: {end}')
                self.log(f'VIP: {"是" if info.get("is_vip") else "否"} | 允许连接: {"是" if info.get("allow_connect") else "否"}')
                self.set_status(f'剩余 {h}h{m}m | 到期 {end}')
            else:
                self.log(f'查询失败: {result}')
                self.set_status('查询失败')
        except Exception as e:
            self.log(f'❌ 异常: {e}')
            self.set_status(f'错误: {e}')
        finally:
            self.running = False
            self.set_buttons(True)

    def do_kill(self):
        self._kill_jumper()
        self.set_status('JumperVPN 已停止')

    # ============================================================
    # 写配置
    # ============================================================
    def _write_config(self, token, imei, user_info, default_node, node_url=''):
        self.log('写入本地配置 ...')
        APP_DIR.mkdir(parents=True, exist_ok=True)

        try:
            with open(SP_PATH, 'r', encoding='utf-8') as f:
                sp = json.load(f)
        except:
            sp = {}

        user_data = {
            'uid': user_info.get('uid', ''),
            'email': user_info.get('email', '') or self.current_email,
            'invite_code': user_info.get('invite_code', ''),
            'free_end_time': user_info.get('free_end_time', ''),
            'free_end_time_str': user_info.get('free_end_time_str', ''),
            'free_end_time_str_en_us': user_info.get('free_end_time_str_en_us', ''),
            'free_end_time_str_zh_cn': user_info.get('free_end_time_str_zh_cn', ''),
            'vip_end_time': user_info.get('vip_end_time', ''),
            'title': user_info.get('title', PC_NAME),
            'imei': imei,
            'token': token,
            'allow_connect': user_info.get('allow_connect', 1),
            'is_vip': user_info.get('is_vip', 0),
        }
        sp['flutter.user'] = json.dumps(user_data, ensure_ascii=False)
        sp['flutter.isLoggedIn'] = True

        if default_node:
            dn = dict(default_node)
            if node_url:
                dn['node_url'] = node_url
            dn['checked'] = True
            sp['flutter.defaultNode'] = json.dumps(dn, ensure_ascii=False)

        sp['flutter.hasShownOnboarding'] = True
        sp['flutter.hasAcceptedTerms'] = True

        with open(SP_PATH, 'w', encoding='utf-8') as f:
            json.dump(sp, f, ensure_ascii=False, indent=2)

        # sing-box config
        CONFIGS_DIR.mkdir(parents=True, exist_ok=True)
        for old in CONFIGS_DIR.glob('*.json'):
            old.unlink()

        profile_id = str(uuid.uuid4())
        config_path = CONFIGS_DIR / f'{profile_id}.json'
        singbox_outbound = {
            "type": "vless",
            "tag": "Japan-g01-vless-reality",
            "server": "jpga01.jumperservice.com",
            "server_port": 19001,
            "uuid": "0709ba80-f353-4636-85ce-43b82990ac2d",
            "flow": "xtls-rprx-vision",
            "tls": {
                "enabled": True,
                "server_name": "www.speedtest.org",
                "utls": {"enabled": True, "fingerprint": "chrome"},
                "reality": {
                    "enabled": True,
                    "public_key": "g1f1wLjim5gOVGnI5LGUV0dL4iFXPoiepOPZfSxJe14"
                }
            }
        }
        with open(config_path, 'w', encoding='utf-8') as f:
            json.dump({"outbounds": [singbox_outbound]}, f, ensure_ascii=False, indent=2)

        # SQLite
        try:
            conn = sqlite3.connect(str(DB_PATH))
            cur = conn.cursor()
            cur.execute('DELETE FROM profile_entries')
            cur.execute('''INSERT INTO profile_entries
                (id, type, active, name, url, last_update, update_interval)
                VALUES (?, ?, ?, ?, ?, ?, ?)''',
                (profile_id, 'local', 1,
                 default_node.get('title', 'Japan-g01') if default_node else 'Japan-g01',
                 None, datetime.now().isoformat(), None))
            conn.commit()
            conn.close()
        except Exception as e:
            self.log(f'  ⚠ SQLite: {e}')

        self.log('✅ 配置已写入')

    # ============================================================
    # 辅助
    # ============================================================
    def _kill_jumper(self):
        self.log('杀掉 JumperVPN ...')
        for proc in ['Jumper.exe', 'JumperCli.exe', 'JumperVPN.exe']:
            subprocess.run(['taskkill', '/F', '/IM', proc], capture_output=True, timeout=5)
        time.sleep(1)
        self.log('✅ JumperVPN 已停止')

    def _clean_data(self):
        self.log('清理本地数据 ...')
        if SP_PATH.exists(): SP_PATH.unlink()
        if CONFIGS_DIR.exists(): shutil.rmtree(str(CONFIGS_DIR), ignore_errors=True)
        if DB_PATH.exists():
            for _ in range(5):
                try: DB_PATH.unlink(); break
                except PermissionError:
                    subprocess.run(['taskkill', '/F', '/IM', 'Jumper.exe'], capture_output=True, timeout=5)
                    time.sleep(1)
        self.log('✅ 本地数据已清理')

    def _create_temp_email(self):
        self.log('创建临时邮箱 ...')
        try:
            domains = self.http_get(f'{MAIL_TM}/domains')
            if isinstance(domains, list):
                domain = domains[0].get('domain', 'deltajohnsons.com')
            else:
                domain = domains.get('hydra:member', [{}])[0].get('domain', 'deltajohnsons.com')

            username = ''.join(random.choices(string.ascii_lowercase + string.digits, k=10))
            email = f'{username}@{domain}'
            mail_pwd = ''.join(random.choices(string.ascii_letters + string.digits, k=16))

            self.http_post(f'{MAIL_TM}/accounts', {'address': email, 'password': mail_pwd})
            self.log(f'邮箱: {email}')
        except urllib.error.HTTPError as e:
            err = e.read().decode('utf-8','replace')[:200]
            self.log(f'❌ 创建邮箱失败: {err}')
            return None, None, None

        try:
            token_result = self.http_post(f'{MAIL_TM}/token', {'address': email, 'password': mail_pwd})
            mail_token = token_result.get('token', '')
            if not mail_token:
                self.log('❌ mail token 获取失败')
                return None, None, None
        except urllib.error.HTTPError as e:
            self.log(f'❌ mail token 失败: {e.read().decode("utf-8","replace")[:200]}')
            return None, None, None

        return email, mail_pwd, mail_token

    def _wait_for_code(self, mail_token, max_wait=90):
        self.log(f'等待验证码 (最多{max_wait}秒)...')
        start = time.time()
        while time.time() - start < max_wait:
            try:
                messages = self.http_get(f'{MAIL_TM}/messages',
                    headers={'Authorization': f'Bearer {mail_token}'})
                msg_list = messages.get('hydra:member', []) if isinstance(messages, dict) else messages
                for msg in msg_list:
                    msg_id = msg.get('id', '')
                    if not msg_id: continue
                    detail = self.http_get(f'{MAIL_TM}/messages/{msg_id}',
                        headers={'Authorization': f'Bearer {mail_token}'})
                    body_text = detail.get('text', '') or detail.get('html', '') or ''
                    match = re.search(r'(?:验证码|code|Code|CODE)[：:\s]*(\d{4,6})', body_text)
                    if not match:
                        match = re.search(r'\b(\d{4,6})\b', body_text)
                    if match:
                        code = match.group(1)
                        self.log(f'✅ 验证码: {code}')
                        return code
            except: pass
            time.sleep(3)
        self.log('❌ 等待验证码超时')
        return None

    def run(self):
        self.root.mainloop()

if __name__ == '__main__':
    app = JumperApp()
    app.run()
